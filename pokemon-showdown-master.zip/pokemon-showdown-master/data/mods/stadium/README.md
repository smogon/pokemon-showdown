Stadium
====================

This mod inherits from gen 1, which inherits from gen 2, and then applies the Stadium changes upon the gen 1 engine.

List of major changes:

 * Sleep lasts between 1 and 3 turns.
 * Hyper Beam does recharge after a faint.
 * Critical hits happen way less.
 * Substitute now blocks all status ailments and draining.
 * It allows tradebacks.
 * Partial trapping moves miss and stop their duration upon target switch.
 * Focus Energy actually works.
 * Stat calculations are done properly, burn and para drop are lost if you lose status.
