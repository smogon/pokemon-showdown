export const Scripts: ModdedBattleScriptsData = {
	gen: 7,
};
